from setuptools import setup

setup(
    name="end_points",
    version="1-0",
    description="this packages set up the end points ",
    author='Aldo Villalba',
    author_email="aldo.villalba@globant.com",
    packages=["end_points"]
)
