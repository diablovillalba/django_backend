import requests
"""
Class to set up all necessaries endpoints
"""
class Set_up_end_points():

    def __init__(self, url):
        self.url=url

    def initialize_end_point(self):
        response = requests.get(self.url)
        return response
